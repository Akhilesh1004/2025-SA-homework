function to_attributes(tag, timestamp, record)
    local attrs = {}

    local keys = {
        "sa.uri",
        "sa.host",
        "sa.method",
        "sa.user_agent",
        "sa.status"
    }

    for _, k in ipairs(keys) do
        local v = record[k]
        if v ~= nil then
            table.insert(attrs, { key = k, value = v })
            record[k] = nil -- 移除原始鍵，避免被當成 body
        end
    end

    record["attributes"] = attrs
    return 1, timestamp, record
end
