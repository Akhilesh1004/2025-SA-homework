#!/bin/bash
set -e

echo "Configuring pg_hba.conf for client cert auth..."
cat /docker-entrypoint-initdb.d/pg_hba.conf.template > "$PGDATA/pg_hba.conf"
