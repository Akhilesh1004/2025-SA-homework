import express from "express";
import basicAuth from "express-basic-auth";
import { Pool } from "pg";
import fetch from "node-fetch";
import crypto from "crypto";
import fs from "fs";
import https from "https";
import url from "url";

const app = express();
app.use(express.json());

// -----------------------------
//  Load TLS client certs
// -----------------------------
const rootCert = fs.readFileSync("/app/certs/root.crt");
const clientCert = fs.readFileSync("/app/certs/judge.crt");
const clientKey = fs.readFileSync("/app/certs/judge.key");

const agent = new https.Agent({
  rejectUnauthorized: false,
});

// PostgreSQL Pool (TLS + client cert)
const pool = new Pool({
  host: process.env.PGHOST,
  port: 5432,
  database: "uurl",
  user: "judge",
  ssl: {
    rejectUnauthorized: true,
    ca: rootCert,
    cert: clientCert,
    key: clientKey,
  },
});

// -----------------------------
//  Prometheus Metrics
// -----------------------------
let sa_redirects_total = 0;
let sa_redirects_not_found_total = 0;
let sa_created_urls_total = 0;

let containerId = "";
try {
  containerId = fs.readFileSync("/proc/self/cgroup", "utf8")
    .split("\n")
    .reverse()[1]
    .split("/")
    .pop()
    .substring(0, 12);
} catch {
  containerId = "localdev0000";
}

// -----------------------------
//  OIDC Token Validation
// -----------------------------
async function verifyToken(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith("Bearer "))
    return res.status(401).json({ error: "Missing token" });

  const token = auth.slice(7);

  try {
    const resp = await fetch(process.env.INTROSPECTION_URL, {
      method: "POST",
      dispatcher: agent,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization:
          "Basic " +
          Buffer.from(
            process.env.CLIENT_ID + ":" + process.env.CLIENT_SECRET
          ).toString("base64"),
      },
      body: `token=${token}`,
    });

    const data = await resp.json();
    if (!data.active) return res.status(401).json({ error: "Invalid token" });

    req.user = data;
    next();
  } catch (err) {
    console.error(err);
    return res.status(401).json({ error: "Token verify failed" });
  }
}

// -----------------------------
//  POST /api/shorten
// -----------------------------
app.post("/api/shorten", verifyToken, async (req, res) => {
  const { url: originalUrl } = req.body;
  if (!originalUrl) return res.status(400).json({ error: "url is required" });

  const short = crypto.randomBytes(4).toString("hex");

  await pool.query(
    `INSERT INTO urls (creator, original_url, short_code)
     VALUES ($1, $2, $3)`,
    [req.user.sub || "unknown", originalUrl, short]
  );

  sa_created_urls_total++;

  res.status(201).json({ short_code: short });
});

// -----------------------------
//  GET /-/{code}
// -----------------------------
app.get("/-/:code", verifyToken, async (req, res) => {
  const code = req.params.code;

  const result = await pool.query(
    `SELECT original_url FROM urls WHERE short_code = $1`,
    [code]
  );

  if (result.rows.length === 0) {
    sa_redirects_not_found_total++;
    return res.status(404).json({ error: "Not found" });
  }

  const originalUrl = result.rows[0].original_url;
  sa_redirects_total++;

  res.status(303).set("Location", originalUrl).end();
});

// -----------------------------
//  /metrics （Basic Auth）
// -----------------------------
app.use(
  "/metrics",
  basicAuth({
    users: { sa: process.env.METRICS_PASSWORD },
    challenge: true,
  })
);

app.get("/metrics", (req, res) => {
  res.type("text/plain").send(
    `sa_redirects_total{container="${containerId}"} ${sa_redirects_total}
sa_redirects_not_found_total{container="${containerId}"} ${sa_redirects_not_found_total}
sa_created_urls_total{container="${containerId}"} ${sa_created_urls_total}
`
  );
});

app.listen(3000, () => {
  console.log("uurl service running on port 3000");
});
