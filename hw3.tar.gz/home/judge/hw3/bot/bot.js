import { MatrixClient, SimpleFsStorageProvider, AutojoinRoomsMixin } from "matrix-bot-sdk";
import crypto from "crypto";
import { Pool } from "pg";
import fs from "fs";

const HOMESERVER_URL = "https://matrix.111705034.cs.nycu";
const ACCESS_TOKEN = "mct_0kTfFH4oHlxzE9wNklTswTSR1NFrju_WB0984";

const rootCert   = fs.readFileSync("/app/certs/root.crt");
const clientCert = fs.readFileSync("/app/certs/judge.crt");
const clientKey  = fs.readFileSync("/app/certs/judge.key");

const db = new Pool({
    host: process.env.PGHOST,
    port: 5432,
    database: "uurl",
    user: "judge",
    ssl: {
        rejectUnauthorized: true,
        ca: rootCert,
        cert: clientCert,
        key: clientKey,
    },
});



const storage = new SimpleFsStorageProvider("bot-storage.json");

const client = new MatrixClient(HOMESERVER_URL, ACCESS_TOKEN, storage);

AutojoinRoomsMixin.setupOnClient(client);

console.log("Matrix bot is running...");

client.start().catch(err => console.error(err));

function isValidUrl(str) {
    try {
        const u = new URL(str);
        return u.protocol === "http:" || u.protocol === "https:";
    } catch (e) {
        return false;
    }
}


// -------------------------
//  Helper functions (UURL)
// -------------------------

// POST /api/shorten
async function shortenUrl(sender, originalUrl) {
    const short = crypto.randomBytes(4).toString("hex");

    await db.query(
        `INSERT INTO urls (creator, original_url, short_code)
         VALUES ($1, $2, $3)`,
        [sender, originalUrl, short]
    );

    return `https://i.111705034.cs.nycu/-/${short}`;
}

// GET /-/{code}
async function getUrl(code) {
    const result = await db.query(
        `SELECT original_url FROM urls WHERE short_code=$1`,
        [code]
    );

    if (result.rowCount === 0) return null;
    return result.rows[0].original_url;
}

// GET /api/list (你必須自己在 uurl server 做這個 endpoint)
async function listUrls(sender) {
    try {
        const result = await db.query(
            `SELECT short_code, original_url FROM urls WHERE creator = $1`,
            [sender]
        );
        return result.rows;   // [{short_code, original_url}, ...]
    } catch (err) {
        console.error("listUrls error:", err);
        return null;
    }
}

// -------------------------
//  處理訊息
// -------------------------
client.on("room.message", async (roomId, event) => {
    if (!event.content || event.content.msgtype !== "m.text") return;

    const sender = event.sender;
    const body = event.content.body.trim();

    // 不是 !sa 開頭 → ignore
    if (!body.startsWith("!sa")) return;

    const parts = body.split(" ").filter(Boolean);
    const cmd = parts[1];

    // !sa shorten <url>
    if (cmd === "shorten") {
        if (parts.length !== 3) {
            await client.sendText(roomId, "Usage: !sa shorten <url>");
            return;
        }

        const url = parts[2];
	if (!isValidUrl(url)) {
        	return client.sendMessage(roomId, {
            		msgtype: "m.notice",
            		body: "Usage: !sa shorten <url>"
        	});
    	}
        const short = await shortenUrl(sender, url);
        if (!short)
            await client.sendText(roomId, "Usage: !sa shorten <url>");
        else
            await client.sendText(roomId, short);

        return;
    }

    // !sa get <code>
    if (cmd === "get") {
        if (parts.length !== 3) {
            await client.sendText(roomId, "Usage: !sa get <short_code>");
            return;
        }

        const code = parts[2];
        const origin = await getUrl(code);
        if (!origin)
            await client.sendText(roomId, "Usage: !sa get <short_code>");
        else
            await client.sendText(roomId, origin);

        return;
    }

    // !sa list
    if (cmd === "list") {
        const data = await listUrls(sender);
        if (!data) {
            await client.sendText(roomId, "Error listing URLs");
            return;
        }

        const reply = data.map(row => `${row.short_code} => ${row.original_url}`).join("\n");
        await client.sendText(roomId, reply || "(empty)");
        return;
    }

    // 其它 !sa
    await client.sendText(roomId, "Usage: !sa {shorten|get|list}");
});
